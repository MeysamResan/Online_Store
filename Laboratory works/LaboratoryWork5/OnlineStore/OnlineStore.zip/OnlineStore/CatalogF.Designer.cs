﻿
namespace OnlineStore
{
    partial class CatalogF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CatalogF));
            this.Product1BTN = new System.Windows.Forms.Button();
            this.Product2BTN = new System.Windows.Forms.Button();
            this.Product3BTN = new System.Windows.Forms.Button();
            this.Product4BTN = new System.Windows.Forms.Button();
            this.Product5BTN = new System.Windows.Forms.Button();
            this.Product6BTN = new System.Windows.Forms.Button();
            this.Product7BTN = new System.Windows.Forms.Button();
            this.Product8BTN = new System.Windows.Forms.Button();
            this.Product9BTN = new System.Windows.Forms.Button();
            this.BackToMainMenuBTN2 = new System.Windows.Forms.Button();
            this.CheckoutBTN2 = new System.Windows.Forms.Button();
            this.TotalPriceTXTBX = new System.Windows.Forms.TextBox();
            this.Product1Label = new System.Windows.Forms.Label();
            this.Product2Label = new System.Windows.Forms.Label();
            this.Product3Label = new System.Windows.Forms.Label();
            this.Product6Label = new System.Windows.Forms.Label();
            this.Product5Label = new System.Windows.Forms.Label();
            this.Product4Label = new System.Windows.Forms.Label();
            this.Product9Label = new System.Windows.Forms.Label();
            this.Product8Label = new System.Windows.Forms.Label();
            this.Product7Label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Product1BTN
            // 
            this.Product1BTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Product1BTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Product1BTN.Image = ((System.Drawing.Image)(resources.GetObject("Product1BTN.Image")));
            this.Product1BTN.Location = new System.Drawing.Point(12, 12);
            this.Product1BTN.Name = "Product1BTN";
            this.Product1BTN.Size = new System.Drawing.Size(100, 100);
            this.Product1BTN.TabIndex = 0;
            this.Product1BTN.UseVisualStyleBackColor = false;
            this.Product1BTN.Click += new System.EventHandler(this.Product1BTN_Click);
            // 
            // Product2BTN
            // 
            this.Product2BTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Product2BTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Product2BTN.Image = ((System.Drawing.Image)(resources.GetObject("Product2BTN.Image")));
            this.Product2BTN.Location = new System.Drawing.Point(118, 12);
            this.Product2BTN.Name = "Product2BTN";
            this.Product2BTN.Size = new System.Drawing.Size(100, 100);
            this.Product2BTN.TabIndex = 1;
            this.Product2BTN.UseVisualStyleBackColor = false;
            this.Product2BTN.Click += new System.EventHandler(this.Product2BTN_Click);
            // 
            // Product3BTN
            // 
            this.Product3BTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Product3BTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Product3BTN.Image = ((System.Drawing.Image)(resources.GetObject("Product3BTN.Image")));
            this.Product3BTN.Location = new System.Drawing.Point(224, 12);
            this.Product3BTN.Name = "Product3BTN";
            this.Product3BTN.Size = new System.Drawing.Size(100, 100);
            this.Product3BTN.TabIndex = 2;
            this.Product3BTN.UseVisualStyleBackColor = false;
            this.Product3BTN.Click += new System.EventHandler(this.Product3BTN_Click);
            // 
            // Product4BTN
            // 
            this.Product4BTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Product4BTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Product4BTN.Image = ((System.Drawing.Image)(resources.GetObject("Product4BTN.Image")));
            this.Product4BTN.Location = new System.Drawing.Point(12, 151);
            this.Product4BTN.Name = "Product4BTN";
            this.Product4BTN.Size = new System.Drawing.Size(100, 100);
            this.Product4BTN.TabIndex = 3;
            this.Product4BTN.UseVisualStyleBackColor = false;
            this.Product4BTN.Click += new System.EventHandler(this.Product4BTN_Click);
            // 
            // Product5BTN
            // 
            this.Product5BTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Product5BTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Product5BTN.Image = ((System.Drawing.Image)(resources.GetObject("Product5BTN.Image")));
            this.Product5BTN.Location = new System.Drawing.Point(118, 151);
            this.Product5BTN.Name = "Product5BTN";
            this.Product5BTN.Size = new System.Drawing.Size(100, 100);
            this.Product5BTN.TabIndex = 4;
            this.Product5BTN.UseVisualStyleBackColor = false;
            this.Product5BTN.Click += new System.EventHandler(this.Product5BTN_Click);
            // 
            // Product6BTN
            // 
            this.Product6BTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Product6BTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Product6BTN.Image = ((System.Drawing.Image)(resources.GetObject("Product6BTN.Image")));
            this.Product6BTN.Location = new System.Drawing.Point(224, 151);
            this.Product6BTN.Name = "Product6BTN";
            this.Product6BTN.Size = new System.Drawing.Size(100, 100);
            this.Product6BTN.TabIndex = 5;
            this.Product6BTN.UseVisualStyleBackColor = false;
            this.Product6BTN.Click += new System.EventHandler(this.Product6BTN_Click);
            // 
            // Product7BTN
            // 
            this.Product7BTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Product7BTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Product7BTN.Image = ((System.Drawing.Image)(resources.GetObject("Product7BTN.Image")));
            this.Product7BTN.Location = new System.Drawing.Point(12, 290);
            this.Product7BTN.Name = "Product7BTN";
            this.Product7BTN.Size = new System.Drawing.Size(100, 100);
            this.Product7BTN.TabIndex = 6;
            this.Product7BTN.UseVisualStyleBackColor = false;
            this.Product7BTN.Click += new System.EventHandler(this.Product7BTN_Click);
            // 
            // Product8BTN
            // 
            this.Product8BTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Product8BTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Product8BTN.Image = ((System.Drawing.Image)(resources.GetObject("Product8BTN.Image")));
            this.Product8BTN.Location = new System.Drawing.Point(118, 290);
            this.Product8BTN.Name = "Product8BTN";
            this.Product8BTN.Size = new System.Drawing.Size(100, 100);
            this.Product8BTN.TabIndex = 7;
            this.Product8BTN.UseVisualStyleBackColor = false;
            this.Product8BTN.Click += new System.EventHandler(this.Product8BTN_Click);
            // 
            // Product9BTN
            // 
            this.Product9BTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Product9BTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Product9BTN.Image = ((System.Drawing.Image)(resources.GetObject("Product9BTN.Image")));
            this.Product9BTN.Location = new System.Drawing.Point(224, 290);
            this.Product9BTN.Name = "Product9BTN";
            this.Product9BTN.Size = new System.Drawing.Size(100, 100);
            this.Product9BTN.TabIndex = 8;
            this.Product9BTN.UseVisualStyleBackColor = false;
            this.Product9BTN.Click += new System.EventHandler(this.Product9BTN_Click);
            // 
            // BackToMainMenuBTN2
            // 
            this.BackToMainMenuBTN2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.BackToMainMenuBTN2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BackToMainMenuBTN2.Location = new System.Drawing.Point(12, 455);
            this.BackToMainMenuBTN2.Name = "BackToMainMenuBTN2";
            this.BackToMainMenuBTN2.Size = new System.Drawing.Size(198, 23);
            this.BackToMainMenuBTN2.TabIndex = 10;
            this.BackToMainMenuBTN2.Text = "Вернуться в главное меню";
            this.BackToMainMenuBTN2.UseVisualStyleBackColor = false;
            this.BackToMainMenuBTN2.Click += new System.EventHandler(this.BackToMainMenuBTN2_Click);
            // 
            // CheckoutBTN2
            // 
            this.CheckoutBTN2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.CheckoutBTN2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CheckoutBTN2.Location = new System.Drawing.Point(216, 455);
            this.CheckoutBTN2.Name = "CheckoutBTN2";
            this.CheckoutBTN2.Size = new System.Drawing.Size(108, 23);
            this.CheckoutBTN2.TabIndex = 11;
            this.CheckoutBTN2.Text = "Оформить заказ";
            this.CheckoutBTN2.UseVisualStyleBackColor = false;
            this.CheckoutBTN2.Click += new System.EventHandler(this.CheckoutBTN2_Click);
            // 
            // TotalPriceTXTBX
            // 
            this.TotalPriceTXTBX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalPriceTXTBX.Location = new System.Drawing.Point(12, 429);
            this.TotalPriceTXTBX.Name = "TotalPriceTXTBX";
            this.TotalPriceTXTBX.Size = new System.Drawing.Size(312, 20);
            this.TotalPriceTXTBX.TabIndex = 12;
            this.TotalPriceTXTBX.TextChanged += new System.EventHandler(this.TotalPriceTXTBX_TextChanged);
            // 
            // Product1Label
            // 
            this.Product1Label.Location = new System.Drawing.Point(12, 115);
            this.Product1Label.Name = "Product1Label";
            this.Product1Label.Size = new System.Drawing.Size(100, 33);
            this.Product1Label.TabIndex = 13;
            this.Product1Label.Text = "Smartwatch\r\n25 000 ₽\r\n";
            this.Product1Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Product1Label.Click += new System.EventHandler(this.Product1Label_Click);
            // 
            // Product2Label
            // 
            this.Product2Label.Location = new System.Drawing.Point(118, 115);
            this.Product2Label.Name = "Product2Label";
            this.Product2Label.Size = new System.Drawing.Size(100, 33);
            this.Product2Label.TabIndex = 14;
            this.Product2Label.Text = "iPhone\r\n75 000 ₽";
            this.Product2Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Product2Label.Click += new System.EventHandler(this.Product2Label_Click);
            // 
            // Product3Label
            // 
            this.Product3Label.Location = new System.Drawing.Point(224, 115);
            this.Product3Label.Name = "Product3Label";
            this.Product3Label.Size = new System.Drawing.Size(100, 33);
            this.Product3Label.TabIndex = 15;
            this.Product3Label.Text = "iPad\r\n100 000 ₽";
            this.Product3Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Product3Label.Click += new System.EventHandler(this.Product3Label_Click);
            // 
            // Product6Label
            // 
            this.Product6Label.Location = new System.Drawing.Point(224, 254);
            this.Product6Label.Name = "Product6Label";
            this.Product6Label.Size = new System.Drawing.Size(100, 33);
            this.Product6Label.TabIndex = 18;
            this.Product6Label.Text = "Gaming PC\r\n140 000 ₽";
            this.Product6Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Product6Label.Click += new System.EventHandler(this.Product6Label_Click);
            // 
            // Product5Label
            // 
            this.Product5Label.Location = new System.Drawing.Point(118, 254);
            this.Product5Label.Name = "Product5Label";
            this.Product5Label.Size = new System.Drawing.Size(100, 33);
            this.Product5Label.TabIndex = 17;
            this.Product5Label.Text = "Playstation 5\r\n40 000 ₽";
            this.Product5Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Product5Label.Click += new System.EventHandler(this.Product5Label_Click);
            // 
            // Product4Label
            // 
            this.Product4Label.Location = new System.Drawing.Point(12, 254);
            this.Product4Label.Name = "Product4Label";
            this.Product4Label.Size = new System.Drawing.Size(100, 33);
            this.Product4Label.TabIndex = 16;
            this.Product4Label.Text = "Macbook\r\n150 000 ₽";
            this.Product4Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Product4Label.Click += new System.EventHandler(this.Product4Label_Click);
            // 
            // Product9Label
            // 
            this.Product9Label.Location = new System.Drawing.Point(224, 393);
            this.Product9Label.Name = "Product9Label";
            this.Product9Label.Size = new System.Drawing.Size(100, 33);
            this.Product9Label.TabIndex = 21;
            this.Product9Label.Text = "Piano\r\n2 000 000 ₽";
            this.Product9Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Product9Label.Click += new System.EventHandler(this.Product9Label_Click);
            // 
            // Product8Label
            // 
            this.Product8Label.Location = new System.Drawing.Point(118, 393);
            this.Product8Label.Name = "Product8Label";
            this.Product8Label.Size = new System.Drawing.Size(100, 33);
            this.Product8Label.TabIndex = 20;
            this.Product8Label.Text = "Gaming chair\r\n15 000 ₽";
            this.Product8Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Product8Label.Click += new System.EventHandler(this.Product8Label_Click);
            // 
            // Product7Label
            // 
            this.Product7Label.Location = new System.Drawing.Point(12, 393);
            this.Product7Label.Name = "Product7Label";
            this.Product7Label.Size = new System.Drawing.Size(100, 33);
            this.Product7Label.TabIndex = 19;
            this.Product7Label.Text = "Gaming monitor\r\n25 000 ₽";
            this.Product7Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Product7Label.Click += new System.EventHandler(this.Product7Label_Click);
            // 
            // CatalogF
            // 
            this.AcceptButton = this.CheckoutBTN2;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.CancelButton = this.BackToMainMenuBTN2;
            this.ClientSize = new System.Drawing.Size(336, 492);
            this.Controls.Add(this.Product9Label);
            this.Controls.Add(this.Product8Label);
            this.Controls.Add(this.Product7Label);
            this.Controls.Add(this.Product6Label);
            this.Controls.Add(this.Product5Label);
            this.Controls.Add(this.Product4Label);
            this.Controls.Add(this.Product3Label);
            this.Controls.Add(this.Product2Label);
            this.Controls.Add(this.Product1Label);
            this.Controls.Add(this.TotalPriceTXTBX);
            this.Controls.Add(this.CheckoutBTN2);
            this.Controls.Add(this.BackToMainMenuBTN2);
            this.Controls.Add(this.Product9BTN);
            this.Controls.Add(this.Product8BTN);
            this.Controls.Add(this.Product7BTN);
            this.Controls.Add(this.Product6BTN);
            this.Controls.Add(this.Product5BTN);
            this.Controls.Add(this.Product4BTN);
            this.Controls.Add(this.Product3BTN);
            this.Controls.Add(this.Product2BTN);
            this.Controls.Add(this.Product1BTN);
            this.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(352, 531);
            this.MinimumSize = new System.Drawing.Size(352, 531);
            this.Name = "CatalogF";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Catalog";
            this.Load += new System.EventHandler(this.CatalogF_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Product1BTN;
        private System.Windows.Forms.Button Product2BTN;
        private System.Windows.Forms.Button Product3BTN;
        private System.Windows.Forms.Button Product4BTN;
        private System.Windows.Forms.Button Product5BTN;
        private System.Windows.Forms.Button Product6BTN;
        private System.Windows.Forms.Button Product7BTN;
        private System.Windows.Forms.Button Product8BTN;
        private System.Windows.Forms.Button Product9BTN;
        private System.Windows.Forms.Button BackToMainMenuBTN2;
        private System.Windows.Forms.Button CheckoutBTN2;
        private System.Windows.Forms.TextBox TotalPriceTXTBX;
        public System.Windows.Forms.Label Product1Label;
        private System.Windows.Forms.Label Product2Label;
        private System.Windows.Forms.Label Product3Label;
        private System.Windows.Forms.Label Product6Label;
        private System.Windows.Forms.Label Product5Label;
        private System.Windows.Forms.Label Product4Label;
        private System.Windows.Forms.Label Product9Label;
        private System.Windows.Forms.Label Product8Label;
        private System.Windows.Forms.Label Product7Label;
    }
}